


<?php $__env->startSection('title'); ?>
/
<span>بيانات   
الاعضاء
 </span>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

 


<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2 dir_rtl" style="text-align: center;">
            <div class="panel panel-default">
                <div class="panel-heading"></div>
                <div class="panel-body" >
                <h3>
                <a href="/admin/member/create" class="btn btn-primary">انشاء 
                 عضو</a>
                </h3>
            </div>

        </div>
    </div>
</div>

 <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <div class="tile-body">
          <table class="table table-hover table-bordered" id="sampleTable">
            <thead>
                    <tr>
                    <th>ID</th>
                    <th>الاسم</th>
                    <th>البيانات </th>
                    <th>النوع </th>

                    <th>-</th>

                    <th>-</th>
                </tr>
                </thead>
                <tbody>  
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($user->id); ?> </td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                     <td>
                        <?php if(!empty($user->getRoleNames())): ?>
                        <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <a class="badge-success btn btn-default"><?php echo e($v); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php endif; ?>    
                   </td>                     
                   <td>
                        <a href="/admin/member/<?php echo e($user->id); ?>/edit" class="btn btn-default">
                        <i class="fa fa-edit"></i>
                        التحرير</a>
                    </td>
                     
                    <td>

                         <?php if(!is_null($user->deleted_at)): ?>                        
                       
                        <?php echo Form::open(['action' => ['App\Http\Controllers\UserController@restorUser',$user->id],'method'=>'GET', 'class'=>'pull-right' ]); ?>

                        <?php echo e(Form::hidden('_method','GET')); ?>

                        <?php echo e(Form::submit(' إستعادة',['class'=>'btn btn-info'])); ?>

                        <?php echo Form::close(); ?>

                        <br>
                        <?php echo Form::open(['action' => ['App\Http\Controllers\UserController@froceDestroy',$user->id],'method'=>'POST', 'class'=>'pull-right','onsubmit' => 'return ConfirmDelete()']); ?>

                        <?php echo e(Form::hidden('_method','DELETE')); ?>

                        <?php echo e(Form::submit('حذف نهائي ',['class'=>'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                       
                        <?php else: ?> 
                        <?php echo Form::open(['action' => ['App\Http\Controllers\UserController@destroy',$user->id],'method'=>'POST', 'class'=>'pull-right','onsubmit' => 'return ConfirmDelete()']); ?>

                        <?php echo e(Form::hidden('_method','DELETE')); ?>

                        <?php echo e(Form::submit('الحذف',['class'=>'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                       
                        <?php endif; ?>
                    </td>
      
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>

                
    
</div>

<script>      
    function ConfirmDelete( )
    {
       var msg = "هل تريد فعلاً   حذف  "+"?";
    var x = confirm(    msg);
    if (x)
      return true;
    else
      return false;
    }
  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/users/list.blade.php ENDPATH**/ ?>