 
 <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
       
      <ul class="app-menu">

        <li><a class="app-menu__item <?php echo e((\Request::is('/admin') ? 'active' : '')); ?>" href="/admin"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">الرئيسة</span></a></li>
            
       </li>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list salons')): ?>
       <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/salon*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-calendar-check-o">
      </i><span class="app-menu__label"> الصوالين </span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/salon"><i class="icon fa fa-plus-square "></i> الكل</a></li>
        </ul>
      </li>
     <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list services')): ?>
       <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/service*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-calendar-check-o">
       </i><span class="app-menu__label">  الخدمات </span><i class="treeview-indicator fa fa-angle-left"></i></a>
       <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/service/create"><i class="icon fa fa-plus-square "></i> إضافة منتج</a></li>
         <li><a class="treeview-item  mr-2" href="/admin/service"><i class="icon fa fa-plus-square "></i> الكل</a></li>
         </ul>
       </li>
       <?php endif; ?>
       <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list promotions')): ?>
       <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/slide*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-calendar-check-o">
      </i><span class="app-menu__label"> العروض </span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/promotion"><i class="icon fa fa-plus-square "></i> slide</a></li>
        </ul>
      </li>
     <?php endif; ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list reservations')): ?>
      <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/reservation*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-calendar-check-o">
      </i><span class="app-menu__label"> الحجوزات </span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/reservation"><i class="icon fa fa-plus-square "></i> الكل</a></li>
        </ul>
      </li>
      <?php endif; ?>
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list report')): ?>

      <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/reports*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-calendar-check-o">
      </i><span class="app-menu__label"> التقارير </span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/reports"><i class="icon fa fa-plus-square "></i> الطلبات</a></li>
        
        </ul>
      </li>
      <?php endif; ?>
     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list users')): ?>
     <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/member*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user">
    </i><span class="app-menu__label">  التحكم بالاعضاء</span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
      <li><a class="treeview-item  mr-2" href="/admin/member"><i class="icon fa fa-plus-square "></i> الكل</a></li>
        
    </ul>
    </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list roles')): ?>
    <li class="treeview"><a class="app-menu__item <?php echo e((Request::is('/admin/role*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-user">
   </i><span class="app-menu__label">  التحكم بالصلاحيات</span><i class="treeview-indicator fa fa-angle-left"></i></a>
     <ul class="treeview-menu">
     <li><a class="treeview-item  mr-2" href="/admin/roles"><i class="icon fa fa-plus-square "></i> الكل</a></li>
     </ul>
   </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list settings')): ?>
   <li class="treeview"><a class="app-menu__item <?php echo e((\Request::is('/admin/settings/*') ? 'active' : '')); ?>" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">  اعدادت </span><i class="treeview-indicator fa fa-angle-left"></i></a>
      <ul class="treeview-menu">
        <li><a class="treeview-item  mr-2" href="/admin/settings" rel="noopener"><i class="icon fa fa-edit"></i> الموقع</a></li>
        <li><a class="treeview-item  mr-2" href="/admin/braintree" rel="noopener"><i class="icon fa fa-edit"></i> braintree الدفع</a></li>
        </ul>
   </li>
        <?php endif; ?>
      </ul>
    </aside><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/vadmin/sidebar.blade.php ENDPATH**/ ?>