<header class="app-header"><a class="app-header__logo" href="/"><?php echo e($info->nameAr); ?>   </a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
         
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
        <i class="fa fa-user fa-lg"></i>
          
        <span class="app-sidebar__user-name"><?php echo e(Auth::user()->name); ?></span>
         
        </a>
          <ul class="dropdown-menu settings-menu dropdown-menu-left">
            
            <li><a class="dropdown-item" href="/setting/"><i class="fa fa-cog fa-lg"></i> اعدادات</a></li>
            
            <li><a class="dropdown-item" href="/user/profile"><i class="fa fa-user fa-lg"></i> البروفايل</a></li>
            <li>
            <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" id="navbar-static-login" class="nav-link waves-effect waves-light" >

            <i class="fa fa-sign-out fa-lg"></i> خروج</a></li>
          </ul>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
        </li>
      </ul>
    </header><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/vadmin/header.blade.php ENDPATH**/ ?>