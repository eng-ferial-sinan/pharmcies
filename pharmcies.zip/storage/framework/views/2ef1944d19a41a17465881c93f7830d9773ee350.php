<header class="app-header"><a class="app-header__logo" href="/admin"><?php echo e($info->nameAr); ?>   </a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
         
        <li class="dropdown">
          <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Show notifications">
            <i class="fa fa-bell-o fa-lg"></i>
       
       
            <span class="badge badge-pill badge-danger float-right"><?php echo e(count(\Auth::user()->unreadnotifications)); ?></span>
          </a>
          <ul class="app-notification dropdown-menu dropdown-menu-left">
               <?php if(count(\Auth::user()->notifications)>0): ?>
              <div class="app-notification__content">
              <?php $__currentLoopData = \Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a class="app-notification__item <?php echo e(($item->read_at ? '' : 'app-notification__unread')); ?>" href="/order/<?php echo e($item->data['id']); ?>"><span class="app-notification__icon"><span class="fa-stack fa-lg"><i class="fa fa-circle fa-stack-2x text-danger"></i><i class="fa fa-hdd-o fa-stack-1x fa-inverse"></i></span></span>
              <div >
                <p class="app-notification__message">
                    <?php echo e($item->data['user']); ?>

                  <br > <?php echo e($item->created_at->diffForHumans()); ?></p>
              </div></a></li>
                <?php $item->markAsRead() ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php else: ?> 
              <li class="app-notification__title"> لديك 0 تنبيهات .</li>
              <?php endif; ?> 
              
              </div>
            </div>
            <li class="app-notification__footer"><a href="/order">عرض الكل.</a></li>
          </ul>
        </li>
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
        <i class="fa fa-user fa-lg"></i>
          
        <span class="app-sidebar__user-name"><?php echo e(Auth::user()->name); ?></span>
         
        </a>
          <ul class="dropdown-menu settings-menu dropdown-menu-left">
            
            <li><a class="dropdown-item" href="/admin/settings"><i class="fa fa-cog fa-lg"></i> اعدادات</a></li>
            
            <li><a class="dropdown-item" href="/admin/user/profile"><i class="fa fa-user fa-lg"></i> البروفايل</a></li>
            <li>
            <a  class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" id="navbar-static-login" class="nav-link waves-effect waves-light" >

            <i class="fa fa-sign-out fa-lg"></i> خروج</a></li>
          </ul>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
        </li>
      </ul>
    </header><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/vadmin/header.blade.php ENDPATH**/ ?>