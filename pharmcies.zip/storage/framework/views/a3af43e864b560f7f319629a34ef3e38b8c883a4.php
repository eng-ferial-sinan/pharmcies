

<?php $__env->startSection('content'); ?>
<?php
function roleName1($name)
 {
      
switch($name)
{
 case "medicine-list": $name = "عرض انواع ادوية"; break;
 case "medicine-create": $name = "انشاء دواء جديد";break;
 case "medicine-edit": $name = "تعديل دواء   ";break;
 case "medicine-delete": $name = "حذف دواء";break;
 case "user-list": $name = "عرض  المستخدمين"; break;
 case "user-create": $name = "انشاء مستخدم جديد";break;
 case "user-edit": $name = "تعديل  المستخدم  ";break;
 case "user-delete": $name = "حذف المستخدم";break;
 case "Pharmacy-list": $name = "عرض الصيدلايات "; break;
 case "Pharmacy-create": $name = "انشاء  صيدلية جديد";break;
 case "Pharmacy-edit": $name = "تعديل صيدلية    ";break;
 case "Pharmacy-delete": $name = "حذف صيدلية";break;
 case "category-list": $name = "عرض الاصناف "; break;
 case "category-create": $name = "انشاء صنف جديد ";break;
 case "category-edit": $name = "تعديل الصنف   ";break;
 case "category-delete": $name = "حذف الصنف";break;
 case "report-list": $name = "عرض  التقارير"; break;
 case "report-create": $name = "انشاء تقرير ";break;
 case "report-edit": $name = "تعديل  تقرير  ";break;
 case "report-delete": $name = "حذف تقرير";break;
 case "order-list": $name = "عرض  الطلبيات"; break;
 case "order-create": $name = "انشاء طلبية ";break;
 case "order-edit": $name = "تعديل  طلبية  ";break;
 case "order-delete": $name = "حذف طلبية";break;
    
}

     return  $name;

 }
?>



<div class="container dir_rtl afrahright">
  <div class="tile ">

    <h3>تحرير   
    بيانات   
<?php echo e($user->name); ?>


                    </h3>
   <?php echo Form::open(['action' => ['App\Http\Controllers\UserController@update',$user->id], 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

    
       <div class="form-group">
            <?php echo e(Form::label('title','الاسم')); ?>

            <?php echo e(Form::text('name', $user->name, ['class' => 'form-control', 'placeholder' => '','required'=>true])); ?>

        </div>
 
        <div class="form-group">
            <?php echo e(Form::label('title','اسم المستخدم')); ?>

            <?php echo e(Form::email('email', $user->email, ['class' => 'form-control', 'placeholder' => '','readonly'=>true])); ?>

        </div>

 
        <div class="form-group">
            <?php echo e(Form::label('title',' الجديدة ادخل كلمة المرور')); ?>

            <?php echo e(Form::text('password', '', ['placeholder' => ' كلمة المرور','class' => 'form-control','required'=>true])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('title','  تاكيد كلمة المرور')); ?>

            <?php echo Form::text('confirm-password','', array('placeholder' => ' تاكيد كلمة المرور','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
          <?php echo e(Form::label('title','الصلاحيات')); ?>

          
          <?php echo e(Form::select('roles', $roles,$userRole, ['class' => 'custom-select', 'placeholder' => 'اختر نوع المستخدم','required'=>true])); ?>


      </div>      
     
    
       
    <?php echo e(Form::hidden('_method','PUT')); ?>

    <?php echo e(Form::submit('تعديل',['class'=>'btn btn-primary'])); ?>    
    <?php echo Form::close(); ?>   
  </div>
</div>
    <script>
 
        
          
            function ConfirmDelete()
            {
            var x = confirm("هل تريد فعلاً الحذف؟");
            if (x)
              return true;
            else
              return false;
            }
          
    </script>
 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
    
     
    $('.select2').select2();  
                       
    
      $('.counter_id').select2({
            width: '100%',
            dropdownParent: $("#add")
        })
       
           
       </script>
    
    <!--script  src="/date/js/index.js"></script-->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>