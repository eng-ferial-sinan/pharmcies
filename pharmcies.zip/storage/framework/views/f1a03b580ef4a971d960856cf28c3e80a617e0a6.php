

<?php $__env->startSection('title'); ?>   /
بيانات   
    promotion

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="container"> 


    <div class="row">
        <div class="col-md-12  " style="text-align: center;">
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add promotion')): ?>
          <a href="" data-toggle="modal" data-target="#add" class="btn btn-info float-left">
                    <i class="fa fa-plus fa-2x"></i> اضافة promotion
                </a>
            <?php endif; ?>

    </div>
</div>

<?php
$categories=\App\Models\Salon::all();
?>

<?php if(count($promotions)>0): ?>
<div class="row">
 <div class="col-md-12">
   <div class="tile">
     <div class="tile-body">
       <div class="table-responsive">
       <table class="table table-hover table-bordered " id="sampleTable">
                        <thead>
                       <tr>
                    <th>#</th>
                    <th>#</th>
                    <th>الترتيب</th>
                    <th>الصالون</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit promotion')): ?>
                    <th>-</th>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete promotion')): ?>
                    <th>-</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>  
                    <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($promotion->id); ?> </td>
                    <td><img src="<?php echo e($promotion->image); ?>" height="80" width="75"></td>

                    <td><?php echo e($promotion->sort); ?></a></td>
                    <td><?php echo e($promotion->salon?$promotion->salon->name:''); ?></td>

            
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit promotion')): ?>
                    <td> <a  href="" data-toggle="modal" data-target="#edit<?php echo e($promotion->id); ?>" class="btn btn-warning mr-3 ml-2">
                        <i class="fa fa-edit fa-2x"></i>
                        </a>
                        
                        
                        

<div class="modal hide fade in " data-keyboard="false" data-backdrop="static" id="edit<?php echo e($promotion->id); ?>">
 <div class="modal-dialog modal-xl" >
   <div class="modal-content">
     <div class="modal-header">
       <h5 class="modal-title">  تعديل بيانات promotion <?php echo e($promotion->id); ?></h5>
       <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
     </div>
     <div class="modal-body">
     <?php echo Form::open(['action' => ['App\Http\Controllers\PromotionController@update',$promotion->id], 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

     

     <div class="form-group">
      <?php echo e(Form::label('salon_id','الصالون ')); ?>

      <select name="salon_id" class="select2 form-control" required  >
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($salon->id); ?>"  <?php if($salon->id == $promotion->salon_id): ?> selected <?php endif; ?> >
         <?php echo e($salon->name); ?>

      </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      </select>
     
      <div class="form-group">
        <?php echo e(Form::label('sort',' الترتيب')); ?>

        <?php echo e(Form::number('sort',$promotion->sort, ['class' => 'form-control', 'placeholder' => 'الترتيب','required'=>true])); ?>

        </div>

  

<div class="form-group">
  <img src="<?php echo e($promotion->image); ?>" class="img-rounded" height="50" width="70" alt="<?php echo e($promotion->id); ?>">
   <br/>
    <?php echo e(Form::label('image','صورة معبرة')); ?>

     <?php echo e(Form::file('image')); ?>

 </div>
<?php echo e(Form::hidden('_method','PUT')); ?>


</div>
     <div class="modal-footer">
       <button class="btn btn-primary" type="submit">  حفظ التعديلات</button>
       <?php echo Form::close(); ?>      
       <button class="btn btn-secondary" type="button" data-dismiss="modal">اغلاق</button>
     </div>
   </div>
 </div>
</div>
</div>

</td>
                     
                    <?php endif; ?>
                    
                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete promotion')): ?>
                    <td>

 
                        <?php echo Form::open(['action' => ['App\Http\Controllers\PromotionController@destroy',$promotion->id],'method'=>'POST', 'class'=>'pull-right','onsubmit' => 'return ConfirmDelete()']); ?>

                        <?php echo e(Form::hidden('_method','DELETE')); ?>

                        <?php echo e(Form::submit('الحذف',['class'=>'btn btn-danger'])); ?>

                        <?php echo Form::close(); ?>

                       
                        
                    </td>

                    <?php endif; ?>
      
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                
                    </tbody>

                </table>
            </div>
        </div>
      </div>
      </div>
    </div>
    <?php else: ?>
    <p> لا توجد بيانات حالياً</p>
<?php endif; ?>
                
</div>
    
<div class="modal fade" id="add">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">  اضافة promotion  جديد</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo Form::open(['action' => 'App\Http\Controllers\PromotionController@store', 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

         
          <div class="form-group">
            <?php echo e(Form::label('salon_id','الصالون ')); ?>

            <select name="salon_id" class="select2 form-control" required  >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($salon->id); ?>"   >
               <?php echo e($salon->name); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </select>
  <div class="form-group">
    <?php echo e(Form::label('sort',' الترتيب')); ?>

    <?php echo e(Form::number('sort',0, ['class' => 'form-control', 'placeholder' => 'الترتيب','required'=>true])); ?>

    </div>
  
  <div class="form-group">
     <br/>
      <?php echo e(Form::label('image','صورة معبرة')); ?>

       <?php echo e(Form::file('image')); ?>

   </div>
           </div>
        <div class="modal-footer justify-content-between">
          <button type="submit" class="btn btn-primary">حفظ </button>
          <button type="button" class="btn btn-default" data-dismiss="modal">الغاء</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  

<script>      
    function ConfirmDelete( )
    {
       var msg = "هل تريد فعلاً   حذف  "+"?";
    var x = confirm(    msg);
    if (x)
      return true;
    else
      return false;
    }
  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/promotion/index.blade.php ENDPATH**/ ?>