

<?php $__env->startSection('head'); ?>   /
بيانات   الخدمةات

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="tile ">

<div class="panel panel-default">
    <?php if($item->id == null): ?>
    <div class="panel-heading">
    اضافة   
    بيانات   
  </div>
  <?php else: ?> 
  <div class="panel-heading">
    تحرير   
    بيانات   
  <?php echo e($item->name); ?>  
</div>

  <?php endif; ?>
    
  <div class="panel-body">     
        <form method="post" action="<?php if($item->id == null): ?> <?php echo e(route('service.store')); ?> <?php else: ?> <?php echo e(route('service.update', ['service' => $item->id])); ?> <?php endif; ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php if($item->id != null): ?>
            <?php echo e(method_field('PUT')); ?>

        <?php endif; ?>       
        <div class="form-group">
        <?php echo e(Form::label('name','اسم الخدمة')); ?>

        <?php echo e(Form::text('name', $item->name , ['class' => 'form-control', 'placeholder' => 'الاسم','required'=>true])); ?>

        </div>
        <div class="form-group">
          <?php echo e(Form::label('desc',' الوصف')); ?>

          <?php echo e(Form::text('desc', $item->desc , ['class' => 'form-control', 'placeholder' => 'الوصف','required'=>true])); ?>

          </div>

        <?php
        $categories=\App\Models\Salon::all();
        ?>
        
        
        <div class="form-group">
        <?php echo e(Form::label('salon_id','الصالون ')); ?>

        <select name="salon_id" class="select2 form-control" required  >
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($salon->id); ?>"  <?php if($salon->id == $item->salon_id): ?> selected <?php endif; ?> >
           <?php echo e($salon->name); ?>

        </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </select>
        
        </div>
        
        <div class="form-group">
        <?php echo e(Form::label('price',' السعر')); ?>

        <?php echo e(Form::number('price',$item->price, ['class' => 'form-control', 'placeholder' => 'السعر','required'=>true])); ?>

        </div>
        <div class="form-group">
          <?php echo e(Form::label('sort',' الترتيب')); ?>

          <?php echo e(Form::number('sort',$item->sort, ['class' => 'form-control', 'placeholder' => 'الترتيب','required'=>true])); ?>

          </div>

        <div class="form-group">
          <img src="<?php echo e($item->image); ?>" class="img-rounded" height="50" width="70" alt="<?php echo e($item->name); ?>">
           <br/>
            <?php echo e(Form::label('image','صورة معبرة')); ?>

             <?php echo e(Form::file('image')); ?>

         </div>
                 </div>
              <div class="modal-footer justify-content-between">
                <button type="submit" class="btn btn-primary">حفظ </button>
                <a href="\admin\service" class="btn btn-default" data-dismiss="modal">الغاء</a>
              </div>
        </form>
      </div>
</div>
    <script>
            function ConfirmDelete()
            {
            var x = confirm("هل تريد فعلاً الحذف؟");
            if (x)
              return true;
            else
              return false;
            }
          
    </script>
    
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/Service/form.blade.php ENDPATH**/ ?>