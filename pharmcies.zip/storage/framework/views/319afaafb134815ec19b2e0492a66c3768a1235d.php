

<?php 

$info= sitinfo();
?>
<!DOCTYPE html>
 
<html dir="rtl" lang="ar">
  <head> 
 
     <title>    <?php echo e($info->nameAr); ?> </title>
     <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->yieldContent('head'); ?>
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="/vad1/css/main.css">
    <!-- Font-icon css-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



    <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
    <script>
      window.OneSignal = window.OneSignal || [];
      OneSignal.push(function() {
        OneSignal.init({
          appId: "<?php echo e(config('services.onesignal.app_id')); ?>",
        });
      });

      let externalUserId ="<?php echo e(auth()->user()->id); ?>"; // You will supply the external user id to the OneSignal SDK
        OneSignal.push(function() {
          OneSignal.setExternalUserId(externalUserId);
        });
    </script>

  </head>
  <body class="app sidebar-mini rtl">
  <style>
.app-header {
    background-color: #7572b5;
}
.app-header__logo {
    background-color: #2e46af;
}
.widget-small.info.coloured-icon .icon {
    background-color: #7572b5;
}
.app-sidebar {
    background-color: #212529;
}
.btn-info {
    background-color: #7572b5;
    border-color: #7572b5;
}
  </style>
    <!-- Navbar-->
    <?php echo $__env->make('admin.vadmin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- Sidebar menu-->
    <?php echo $__env->make('admin.vadmin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> <?php echo e($info->nameAr); ?>

          <?php echo $__env->yieldContent('title'); ?>
          </h1>
          <p>لوحة تحكم  </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="/admin/home#">لوحة التحكم</a></li>
        </ul>
      </div>
 

      
      <?php echo $__env->make('admin.inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="/vad1/js/jquery-3.2.1.min.js"></script>
    <script src="/vad1/js/popper.min.js"></script>
    <script src="/vad1/js/bootstrap.min.js"></script>
    <script src="/vad1/js/main.js"></script>

    <!-- The javascript plugin to display page loading on top-->
    <script src="/vad1/js/plugins/pace.min.js"></script>

    <script type="text/javascript" src="/vad1/js/plugins/select2.min.js"></script>

    <!-- Page specific javascripts-->
    <script type="text/javascript" src="/vad1/js/plugins/chart.js"></script>

     <!-- The javascript plugin to display page loading on top-->
     <script src="/vad1/js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="/vad1/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="/vad1/js/plugins/dataTables.bootstrap.min.js"></script>
    <link href="//cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet">
<script src="//cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>

    <script type="text/javascript">
    // $('#sampleTable').DataTable();
    $(document).ready(function() {
    var table = $('#sampleTable').DataTable( {
       rowReorder: {
            selector: 'td:nth-child(2)'
        },
        responsive: true
    } );
} );</script>

      <style type="text/css">
  
    #image_preview{
      
      padding: 1px;
      width: 300px !important;
    }
    #image_preview img{
      width: 300px !important;
     max-height:250px;
      padding: 5px;
    }
    #image_preview1 img{
      width: 200px !important;
      padding: 5px;
    }
  </style>
     

    <?php echo $__env->yieldContent('script'); ?>

<script type="text/javascript">
 $('#demoSelect').select2();
         
  
</script>
<script>      
    function ConfirmDelete( )
    {
       var msg = "هل تريد فعلاً   حذف  "+"?";
    var x = confirm(    msg);
    if (x)
      return true;
    else
      return false;
    }
  
</script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/vadmin/lay.blade.php ENDPATH**/ ?>