
<?php if(count($errors)>0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="<?php echo e((Request::is('admin/*') ? '' : 'pt-5 mt-3')); ?> ">

        <div class="alert alert-danger   text-center">
        <?php echo e($error); ?>

        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="<?php echo e((Request::is('admin/*') ? '' : 'pt-5 mt-3')); ?> ">

    <div class="alert alert-success  text-center">
        <?php echo e(session('success')); ?>

    </div>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="<?php echo e((Request::is('admin/*') ? '' : 'pt-5 mt-3')); ?> ">

    <div class="alert alert-danger  text-center">
        <?php echo e(session('error')); ?>

    </div>
    </div>
<?php endif; ?>
 <?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/inc/messages.blade.php ENDPATH**/ ?>