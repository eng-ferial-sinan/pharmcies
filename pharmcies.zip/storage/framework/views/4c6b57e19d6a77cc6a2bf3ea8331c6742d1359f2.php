
<?php $__env->startSection('title'); ?> - 
إدارة الطلبيات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container"> 
               
                <div class="container">
                  <div class="row">
                <div class="col-md-12">


       </div></div>

       <?php if(count($reservations)>0): ?>
       <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <div class="table-responsive">
              <table class="table table-hover table-breservationed " id="sampleTable">
                <thead>
                  <tr>
                    <th>رقم الطلبية</th>
                    <th>طريقة الدفع </th>
                    <th>الزبون </th>
                    <th>الصالون </th>
                    <th> وقت الحجز</th>
                  
                    <th>عرض</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit reservation')): ?>
                    <th>-</th>
                    <?php endif; ?>
                    

                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   
                    <td><?php echo e($reservation->id); ?></td>
                    <td><?php echo e($reservation->paymentMethod?$reservation->paymentMethod->name:'-'); ?></td>
                    <td><?php echo e($reservation->user?$reservation->user->name:"-"); ?></td>
                    <td><?php echo e($reservation->salon?$reservation->salon->name:"لم يتم تعين سائق بعد"); ?></td>
                    <td><?php echo e($reservation->time); ?></td>

              <td>
              <a href="\admin\reservation\<?php echo e($reservation->id); ?>" class="btn btn-success ">
              <i class="fa fa-eye"></i></a>
                    </td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete reservation')): ?>
                    <td>
                          <?php echo Form::open(['action' => ['App\Http\Controllers\ReservationController@destroy',$reservation->id],'method'=>'POST', 'class'=>'pull-right','onsubmit' => 'return ConfirmDelete()']); ?>

                          <?php echo e(Form::hidden('_method','DELETE')); ?>

                            <button class ="btn btn-danger mr-3 ml-3" type="submit"><i class="fa fa-md fa-trash"></i>
                            </button>
                            <?php echo Form::close(); ?>

                          </td>
                    <?php endif; ?>
                  </tr>                   
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   

                </tbody>
              </table>

            </div>
          </div>
        </div>
        </div>
      </div>
    


                     
                     
                    <?php else: ?>
                        <p> لا توجد بيانات حالياً</p>
                    <?php endif; ?>
        </div>

            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/reservation/index.blade.php ENDPATH**/ ?>