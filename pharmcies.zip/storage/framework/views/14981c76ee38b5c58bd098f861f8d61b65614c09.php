
<?php $__env->startSection('title'); ?> - 
انواع المستخدمين
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
   function roleName1($name)
    {
         
switch($name)
{
    case "list roles": $name = "عرض انواع المستخدمين"; break;
    case "add role": $name = "انشاء نوع جديد";break;
    case "edit role": $name = "تعديل نوع المستخدم  ";break;
    case "delete role": $name = "حذف نوع";break;
    case "list users": $name = "عرض  المستخدمين"; break;
    case "add user": $name = "انشاء مستخدم جديد";break;
    case "edit user": $name = "تعديل  المستخدم  ";break;
    case "delete user": $name = "حذف المستخدم";break;
    case "list services": $name = "عرض الخدمات";break;
    case "add service": $name = "انشاء منتج";break;
    case "edit service": $name = "تعديل المنتج";break;
    case "delete service": $name = "حذف منتج";break;
    case "list reservations": $name = "عرض  الحجوزات"; break;
    case "add reservation": $name = "انشاء حجز جديد";break;
    case "edit reservation": $name = "تعديل  الحجز  ";break;
    case "delete reservation": $name = "حذف الحجز";break;
    case "list salons": $name = "عرض الصوالين"; break;
    case "add salon": $name = "انشاء صالون جديد";break;
    case "edit salon": $name = "تعديل صالون  ";break;
    case "delete salon": $name = "حذف صالون";break;
    case "list report": $name = "عرض  تقارير"; break;
    case "list settings": $name = "عرض  الاعدادات"; break;
    case "edit settings": $name = "تعديل   الاعدادات"; break;
}

        return  $name;
   
    }
?>

<div class="container"> 
               
                <div class="container">
                <div class="row">
                <div class="col-md-12">
                    
       </div></div>
       
       <?php if(count($roles)>0): ?>
       <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered " id="sampleTable">
                <thead>
                  <tr>
                    <th>الاسم</th>
                    <th>الصلاحيات</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit role')): ?>
                    <th>تعديل</th>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                    <th>حذف</th>
                    <?php endif; ?>

                   </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($role->name); ?></td>
                  
                    <td>
                        <?php
                        $rolePermissions = \Spatie\Permission\Models\Permission::join("role_has_permissions","role_has_permissions.permission_id","=","permissions.id")
            ->where("role_has_permissions.role_id",$role->id)
            ->get();
            ?>
                  <?php if(!empty($rolePermissions)): ?>
                        <?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="  badge-success btn btn-success " ><?php echo e(roleName1($Permission->name)); ?>,</label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                     </td>
                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit role')): ?>

            <td> 
              <a  href="" data-toggle="modal" data-target="#edit<?php echo e($role->id); ?>" class="btn btn-warning mr-3 ml-2">
                                       <i class="fa fa-edit fa-2x"></i>
                                       </a>
                                       
                                       

<div class="modal hide fade in " data-keyboard="false" data-backdrop="static" id="edit<?php echo e($role->id); ?>">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">  تعديل بيانات  <?php echo e($role->name); ?></h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    </div>
                    <div class="modal-body">
                    <?php echo Form::open(['action' => ['App\Http\Controllers\RoleController@update',$role->id], 'method' => 'POST','enctype'=>'multipart/form-data']); ?>

                    <div class="form-group">
                        <?php echo Form::text('name', $role->name, array('placeholder' => 'Name','class' => 'form-control')); ?>

        </div>
        <div class="form-group">
<?php
          $permission = \Spatie\Permission\Models\Permission::all();
        $rolePermissions = \DB::table("role_has_permissions")->where("role_has_permissions.role_id",$role->id)
            ->pluck('role_has_permissions.permission_id','role_has_permissions.permission_id')
           ->all();
       ?>
        <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label><?php echo e(Form::checkbox('permission[]', $value->id, in_array($value->id, $rolePermissions) ? true : false, array('class' => 'name'))); ?>

            <?php echo e(roleName1($value->name)); ?></label>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

  
            <?php echo e(Form::hidden('_method','PUT')); ?>

        
         </div>
                    <div class="modal-footer">
                      <button class="btn btn-primary" type="submit">  حفظ التعديلات</button>
                      <?php echo Form::close(); ?>      
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">اغلاق</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
             
                </td>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                    <td>
                    <?php echo Form::open(['action' => ['App\Http\Controllers\RoleController@destroy',$role->id],'method'=>'POST', 'class'=>'pull-right','onsubmit' => 'return ConfirmDelete()']); ?>

                    <?php echo e(Form::hidden('_method','DELETE')); ?>

                       <button class ="btn btn-danger mr-3 ml-3" type="submit"><i class="fa fa-md fa-trash"></i>
                       </button>
                       <?php echo Form::close(); ?></td>
                       <?php endif; ?>

                  </tr>
                   
                   
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
 
                    <?php else: ?>
                        <p> لا توجد بيانات حالياً</p>
                    <?php endif; ?>
        </div>






<!--  data-backdrop="static" id="add" -->


            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>