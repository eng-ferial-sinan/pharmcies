

<?php $__env->startSection('head'); ?>  

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?> /
 <span class="badge badge-info">
الصفحة الشخصية
للعضو  : 
<?php echo e($user->email); ?>

</span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--link rel="stylesheet" href="/date/css/style.css"-->
 
<?php
   function roleName1($name)
    {
         
switch($name)
{
    case "admin": $name = "مشرف الموقع"; break;
    case "delegate": $name = "مندوب  ";break;
    case "delegate2": $name = "صيدلاني  ";break;
  
}

        return  $name;
   
    }
?>

      
        <div class="row">
        <div class="col-md-8">
       
               <div class="tile user-settings">
                <h4 class="line-head">تعديل البيانات الشخصية</h4>
                <form action="/admin/profile/updated" method="POST" class="form-horizontal">
 <?php echo e(csrf_field()); ?>

                  <div class="row mb-4">
                    <div class="col-md-8">
                      <label>الاسم</label>
                      <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                
                  </div>
                  <div class="row">
                    
                    <div class="col-md-8 mb-4">
                      <label>كلمةالسر</label>
                      <input type="password"  name="password" class="form-control  text-right js pr-5"    required  placeholder="كلمة السر  " >
                      <?php if($errors->has('password')): ?>
                      <span class="help-block error_reporting">
                          <strong class="red-text"><?php echo e($errors->first('password')); ?></strong>
                      </span>
                  <?php endif; ?>
                  </div>
                    <div class="clearfix"></div>

                    <div class="col-md-8 mb-4">
                      <label>تاكيد كلمةالسر </label>
                      <input type="password"   name="password_confirmation" class="form-control  text-right js pr-5"    required  placeholder="تاكيد كلمة السر  " >
                      <?php if($errors->has('password')): ?>
                              <span class="help-block error_reporting">
                                  <strong class="red-text"><?php echo e($errors->first('password')); ?></strong>
                              </span>
                          <?php endif; ?>
                                 
                        </div>

                    <div class="clearfix"></div>
                    <div class="col-md-8 mb-4">
                      <label>Mobile No  رقم الجوال</label>
                      <input class="form-control" type="text" name="phone" value="<?php echo e($user->phone); ?>" required>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-8 mb-4">
                      <label>user name اسم المستخدم</label>
                      <input class="form-control" type="text" readonly value="<?php echo e($user->email); ?>">
                    </div>
                  </div>
                  <div class="row mb-10">
                    <div class="col-md-12">
                      <button class="btn btn-primary" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i> حفظ </button>
                    </div>
                  </div>
                </form>

            </div>
         </div>
         <div class="col-md-4 tile user-settings">
         <div class="info"><img class="user-img img-fluid img-responsive" src="<?php echo e($user->url? $user->url:'/img/logo.png'); ?>">
              <h4><?php echo e($user->name); ?></h4>
              
            </div>

            <h4 class="line-head">تعديل الصورة الشخصية</h4>
                   <div class="row mb-4">
                    <div class="col-md-8">
                    <form action="/admin/profile/updated/saveimage" method="POST" class="form-horizontal" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

                      <label>رفع صورة </label>
                      <input class="form-control" type="file" name= "myimg">
                    </div> 
                    <div class="col-md-4">
                       <input class="btn btn-primary" type="submit" value="رفع">
                    </div>
                  </div>
</form>
 
</div>
</div>
         
 











   <?php $__env->stopSection(); ?>

   <?php $__env->startSection('script'); ?>
   <!--script  src="/date/js/index.js"></script-->
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.vadmin.lay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmcies\resources\views/admin/users/profile.blade.php ENDPATH**/ ?>