  <footer class="main-footer">
    <div class="pull-right hidden-xs">
    </div>
    <strong>Copyright &copy; {{ date('Y')}} <a href="{{env('APP_URL')}}">{{env('APP_NAME')}}</a>.</strong> All rights
    reserved.
  </footer>