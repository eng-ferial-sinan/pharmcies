@extends('admin.vadmin.lay')

@section('content')

      <div class="row">
<style>
a {
    color: #594C25;
    text-decoration: none !important;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
</style>
  

  
    
       

         
        </div>
      

      @endsection

   