<!-- Start footer -->
<footer id="mu-footer">
    <div class="mu-footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="mu-single-footer">
                        {{-- <img class="mu-footer-logo" src="assets/images/logo.png" alt="logo"> --}}
<h1>
    {{-- {{$info->nameAr}} --}}
    المستخدم
</h1>
                        <p>ــــــــــــــــــــــــــــ</p>
                        <div class="mu-social-media">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a class="mu-twitter" href="#"><i class="fa fa-twitter"></i></a>
                            <a class="mu-pinterest" href="#"><i class="fa fa-facebook"></i></a>
                            <a class="mu-google-plus" href="#"><i class="fa fa-google-plus"></i></a>
                            <a class="mu-youtube" href="#"><i class="fa fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    
                </div>
                <div class="col-md-3">
                    
                </div>
                <div class="col-md-3">
                    <div class="mu-single-footer">
                        <h3>معلومات التواصل  </h3>
                        <ul class="list-unstyled">
                          <li class="media">
                            <span class="fa fa-home"></span>
                            <div class="media-body">
                                <p>العنوان</p>
                            </div>
                          </li>
                          <li class="media">
                            <span class="fa fa-phone"></span>
                            <div class="media-body">
                               <p>معلومات التلفون</p>
                                 {{-- <p> </p> --}}
                            </div>
                          </li>
                          <li class="media">
                            <span class="fa fa-envelope"></span>
                            <div class="media-body">
                             <p>البريد</p>
                             {{-- <p> {{$info->email}}</p> --}}
                            </div>
                          </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mu-footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mu-footer-bottom-area">
                        <p class="mu-copy-right">&copy; Copyright <a rel="nofollow" href="/">الاسم</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</footer>