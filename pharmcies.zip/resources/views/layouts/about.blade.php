


<section id="mu-about">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-about-area">
					<!-- Title -->
					<div class="row">
						<div class="col-md-12">
							<div class="mu-title">
								{{-- <h2>عن  {{$info->ar_name}}</h2> --}}
								<h2>عن الصيدليات</h2>
								<p></p>
							</div>
						</div>
					</div>
					
					<!-- Start Feature Content -->
					<div class="row">
						<div class="col-md-6">
							<div class="mu-about-left">
								<img class="" src="storage/about.jpg" alt="img">
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="mu-about-right">
								<ul>
									<li>
										<h3>مهمتنا</h3>
									{{-- <p>{{$info->mission}}</p> --}}
									</li>
									<li>
										<h3>رؤيتنا</h3>
										{{-- <p>{{$info->vision}}</p> --}}
									</li>
									<li>
										<h3>قيمنا</h3>
										{{-- <p>{{$info->principle}}</p> --}}
									</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- End Feature Content -->
				</div>
			</div>
		</div>
	</div>
</section>