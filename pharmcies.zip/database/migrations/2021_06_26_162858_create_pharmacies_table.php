<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePharmaciesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pharmacies', function (Blueprint $table) {
            $table->id();
            $table->string("name")->nullable(true);
            $table->string("phone")->nullable(true);
            $table->string("address")->nullable(true);
            $table->string("lat")->nullable(true);
            $table->string("lng")->nullable(true);
            $table->integer("order_count")->nullable(true);
            $table->integer('balance')->nullable(true);
            $table->integer("user_id")->unsigned();
            $table->timestamps();
            $table->softDeletes(); 

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pharmacies');
    }
}
